# ContractLeadGen Frontend (Dark Theme)

This is a production-ready React + Vite + Tailwind frontend built for Vercel.

### Run locally

1. npm install
2. npm run dev

### Build

npm run build

Set environment variable VITE_API_URL to point to your backend URL (on Render) in Vercel.
